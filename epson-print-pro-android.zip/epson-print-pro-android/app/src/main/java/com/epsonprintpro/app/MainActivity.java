package com.epsonprintpro.app;

import android.content.Context;
import android.os.Bundle;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintManager;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private WebView webView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        // إنشاء واجهة بسيطة تحتوي على شاشة عرض وفاتورة وزر طباعة مباشر
        webView = new WebView(this);
        webView.setWebViewClient(new WebViewClient());
        webView.getSettings().setJavaScriptEnabled(true);
        
        // يمكنك تحميل ملف الـ HTML الخاص بفاتورتك هنا (سواء محلي أو رابط)
        // إذا كان الملف مخزناً محلياً في مجلد assets:
        webView.loadUrl("file:///android_asset/index.html");

        setContentView(webView);
    }

    // دالة الطباعة المباشرة التي ترسل الأمر لنظام أندرويد وطابعة Epson مباشرة
    public void printWebPage() {
        PrintManager printManager = (PrintManager) getSystemService(Context.PRINT_SERVICE);
        String jobName = "Invoice_Document";
        
        PrintDocumentAdapter printAdapter = webView.createPrintDocumentAdapter(jobName);
        
        PrintAttributes.Builder builder = new PrintAttributes.Builder();
        builder.setMediaSize(PrintAttributes.MediaSize.ISO_A4);

        if (printManager != null) {
            printManager.print(jobName, printAdapter, builder.build());
        }
    }
}
